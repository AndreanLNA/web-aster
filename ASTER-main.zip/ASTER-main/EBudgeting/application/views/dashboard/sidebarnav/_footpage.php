<footer class="main-footer">
  <div class="float-right d-none d-sm-block">
    <b>Created by</b> Mahasiswa UNS 2020
  </div>
  <strong>Copyright &copy; 2022 <a href="https://adminlte.io">PLN ASTER</a>.</strong> All rights
  reserved.
</footer>