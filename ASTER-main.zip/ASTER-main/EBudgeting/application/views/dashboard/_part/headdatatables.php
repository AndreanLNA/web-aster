  <!-- DataTables -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>DataTables-1.12.1/css/dataTables.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>Buttons-2.2.3/css/buttons.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>ColReorder-1.5.6/css/colReorder.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>DateTime-1.1.2/css/dataTables.dateTime.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>FixedColumns-4.1.0/css/fixedColumns.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>FixedHeader-3.2.3/css/fixedHeader.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>KeyTable-2.7.0/css/keyTable.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>Responsive-2.3.0/css/responsive.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>RowGroup-1.2.0/css/rowGroup.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>RowReorder-1.2.8/css/rowReorder.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>Scroller-2.0.6/css/scroller.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>SearchBuilder-1.3.3/css/searchBuilder.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>SearchPanes-2.0.1/css/searchPanes.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>Select-1.4.0/css/select.bootstrap4.min.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/DataTables/');?>StateRestore-1.1.1/css/stateRestore.bootstrap4.min.css"/>
  