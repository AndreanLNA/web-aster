 <!-- /.content-wrapper -->
 <footer class="main-footer">
     <div class="pull-right hidden-xs">
         <b>Create by</b> Mahasiswa UNS 2020.
     </div>
     <strong>Copyright &copy; 2022 <a href="https://adminlte.io">PLN ASTER</a>.</strong> All rights
     reserved.
 </footer>